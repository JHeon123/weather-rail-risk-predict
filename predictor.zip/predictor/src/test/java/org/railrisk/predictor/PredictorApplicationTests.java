package org.railrisk.predictor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PredictorApplicationTests {

	@Test
	void contextLoads() {
	}

}
